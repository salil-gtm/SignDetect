cd ..
cd SignDetect/
python main.py
